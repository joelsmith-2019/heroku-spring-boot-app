package com.gcu.topic31;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopicApplicationTests {

	@Test
	void contextLoads() {
	}

}
